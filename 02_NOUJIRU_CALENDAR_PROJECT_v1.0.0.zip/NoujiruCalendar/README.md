# 脳汁カレンダー v1.0.0

`noujiru_calendar_v1.html`をAndroid WebViewへ内蔵したオフラインアプリです。

## 機能

- NLv1ログコードの読み込み
- 日別・月別・累計の勉強時間表示
- NCv1バックアップコードの生成・復元
- localStorageによる端末内保存
- 脳汁ポモドーロとは別アプリとして共存

## APK生成

GitHubへ`NoujiruCalendar/`フォルダを配置し、Actionsの
`Build Noujiru Calendar APK`を実行してください。

生成物：`app/build/outputs/apk/debug/app-debug.apk`
