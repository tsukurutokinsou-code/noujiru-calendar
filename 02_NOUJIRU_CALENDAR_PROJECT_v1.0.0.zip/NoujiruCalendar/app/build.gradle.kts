plugins {
    id("com.android.application")
}

android {
    namespace = "com.leroy.noujirucalendar"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.leroy.noujirucalendar"
        minSdk = 24
        targetSdk = 35
        versionCode = 100
        versionName = "1.0.0"
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
