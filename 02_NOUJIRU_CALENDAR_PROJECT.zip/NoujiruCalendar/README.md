# 脳汁カレンダー v1.2.0

- Googleログイン対応
- ポモドーロがFirestoreへ保存した全期間の学習ログを自動取得
- 同じGoogleアカウントでWeb版・ポモドーロAPK版・カレンダーAPK版を同期
- オフライン時は端末内ログを維持
- 固定署名を使用（Firebase登録SHA-1と一致）

GitHub Actionsの `Build Noujiru Calendar APK` から `app-debug.apk` を取得してください。
